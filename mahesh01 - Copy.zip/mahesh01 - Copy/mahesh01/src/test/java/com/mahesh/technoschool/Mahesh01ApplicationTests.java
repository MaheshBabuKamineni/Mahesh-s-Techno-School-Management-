package com.mahesh.technoschool;

import com.mahesh.technoschool.controller.Contact1Controller;
import com.mahesh.technoschool.controller.Contact3Controller;
import com.mahesh.technoschool.controller.Contact4Controller;
import com.mahesh.technoschool.controller.ContactController;
import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.model.Contact3;
import com.mahesh.technoschool.model.Holiday;
import com.mahesh.technoschool.repository.Contact1Repository;
import com.mahesh.technoschool.repository.Contact3Repository;
import com.mahesh.technoschool.repository.ContactRepository;
import com.mahesh.technoschool.repository.HolidaysRepository;
import com.mahesh.technoschool.service.Contact1Service;
import com.mahesh.technoschool.service.ContactService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;
import rommappers.ContactRowMapper;

import javax.sql.DataSource;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
 class Mahesh01ApplicationTests {
	@Mock
	private JdbcTemplate jdbcTemplate;
	@InjectMocks
	private ContactRepository contactRepository;

	@InjectMocks
	private ContactService contactService;
	@Autowired
	private Contact1Repository contact1Repository;

	@Mock
	private Contact1Service contact1Service;
	@InjectMocks

	private Contact1Controller contact1Controller;

	@Mock
	private Authentication authentication;


	@Test
	public void testFindStudentById() {
		// Create a sample Contact3 instance
		Contact3 expectedContact = new Contact3();
		expectedContact.setId(1213L);
		expectedContact.setName("John Doe");
		expectedContact.setExamResult("A (OUTSTANDING)");

		// Mock the behavior of jdbcTemplate.queryForObject
		Mockito.when(jdbcTemplate.queryForObject(
				Mockito.anyString(),
				Mockito.any(Object[].class),
				Mockito.any(RowMapper.class)
		)).thenReturn(expectedContact);

		// Create an instance of Contact3Repository and pass the mocked JdbcTemplate
		Contact3Repository contact3Repository = new Contact3Repository(jdbcTemplate);

		// Call the method to find a student by ID
		Contact3 result = contact3Repository.findStudentById(1L);

		// Assertions to validate the result
		assertEquals(1213L, result.getId().intValue());
		assertEquals("John Doe", result.getName());
		assertEquals("A (OUTSTANDING)", result.getExamResult());
	}


	@Test
	public void testSaveMessageDetails() {
		Contact contact = new Contact();
		contact.setName("John Doe");// Setting up the contact object
		contact.setMessage("Hii how are you");
		contact.setStatus("close");
		contact.setSubject("Regarding my son admission");
		contact.setEmail("mahesh187.mb@gmail.com");
		contact.setMobileNum("8178298903");


		int savedContact = contactRepository.saveContactMsg(contact);

		// Then
		assertNotNull(savedContact);

	}
	/*@Test
	void whenSavingContact1_returnSavedContact1() {
		// Repository test
		Contact1 contact1 = new Contact1();
		contact1.setName("John Doe");
		contact1.setHousePlan("2BHK");
		contact1.setEmail("mahesh187.mb@gmail.com");
		contact1.setMobileNum("8178298903");
		contact1.setStatus("close");
		contact1.setCreatedBy("mahesh");
		contact1.setCreatedAt(11/13/2027);
		// Set other required fields

		int result = contact1Repository.saveContactMsg(contact1);
		assertNotNull(result); // Assuming successful save returns 1


	}*/

	@Test
	public void adminLogin() {
		InMemoryUserDetailsManager userDetailsManager = userDetailsService();

		UserDetails user = userDetailsManager.loadUserByUsername("user");
		UserDetails admin = userDetailsManager.loadUserByUsername("admin");

		assertNotNull(user);
		assertNotNull(admin);

		assertEquals("user", user.getUsername());
		assertEquals("12345", user.getPassword()); // Confirm password in plaintext

		assertEquals("admin", admin.getUsername());
		assertEquals("54321", admin.getPassword()); // Confirm password in plaintext
	}

	public InMemoryUserDetailsManager userDetailsService() {
		UserDetails user = org.springframework.security.core.userdetails.User
				.withUsername("user")
				.password("12345") // Store password in plaintext
				.roles("USER")
				.build();
		UserDetails admin = org.springframework.security.core.userdetails.User
				.withUsername("admin")
				.password("54321") // Store password in plaintext
				.roles("ADMIN")
				.build();
		return new InMemoryUserDetailsManager(user, admin);
	}


	@Test
	public void testCloseMsg() {
		// Mock data
		int messageId = 1;
		String username = null;

		// Mock the service method to return an empty list
		when(contact1Service.findMsgsWithOpenStatus()).thenReturn(Collections.emptyList());

		// Call the controller method
		String result = contact1Controller.closeMsg(messageId, authentication);

		// Verify that the service method was called with the correct arguments
		verify(contact1Service, times(1)).updateMsgStatus(eq(messageId), eq(username));

		// Verify that the result is a redirect
		assert result.equals("redirect:/displayMessages1");
	}


	@Test
	public void testSaveHousingDetails() {
		Contact contact = new Contact();
		contact.setName("John Doe");// Setting up the contact object
		contact.setMessage("Hii how are you");
		contact.setStatus("close");
		contact.setSubject("Regarding my son admission");
		contact.setEmail("mahesh187.mb@gmail.com");
		contact.setMobileNum("8178298903");


		int savedContact = contactRepository.saveContactMsg(contact);

		// Then
		assertNotNull(savedContact);

	}
	@Test
	public void testSaveTransportDetails() {
		Contact contact = new Contact();
		contact.setName("John Doe");// Setting up the contact object
		contact.setMessage("Hii how are you");
		contact.setStatus("close");
		contact.setSubject("Regarding my son admission");
		contact.setEmail("mahesh187.mb@gmail.com");
		contact.setMobileNum("8178298903");


		int savedContact = contactRepository.saveContactMsg(contact);

		// Then
		assertNotNull(savedContact);

	}

	@Test
	public void testSaveFeeDetails() {
		Contact contact = new Contact();
		contact.setName("John Doe");// Setting up the contact object
		contact.setMessage("Hii how are you");
		contact.setStatus("close");
		contact.setSubject("Regarding my son admission");
		contact.setEmail("mahesh187.mb@gmail.com");
		contact.setMobileNum("8178298903");


		int savedContact = contactRepository.saveContactMsg(contact);

		// Then
		assertNotNull(savedContact);

	}
	@Test
	public void testCloseMsg1() {
		// Mock data
		int messageId = 1;
		String username = null;

		// Mock the service method to return an empty list
		when(contact1Service.findMsgsWithOpenStatus()).thenReturn(Collections.emptyList());

		// Call the controller method
		String result = contact1Controller.closeMsg(messageId, authentication);

		// Verify that the service method was called with the correct arguments
		verify(contact1Service, times(1)).updateMsgStatus(eq(messageId), eq(username));

		// Verify that the result is a redirect
		assert result.equals("redirect:/displayMessages1");
	}




}






