INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' Jan 1 ','New Year''s Day','FESTIVAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' Oct 31 ','Halloween','FESTIVAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' Nov 24 ','Thanksgiving Day','FESTIVAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' Dec 25 ','Christmas','FESTIVAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' Jan 17 ','Martin Luther King Jr. Day','FEDERAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' July 4 ','Independence Day','FEDERAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
 VALUES (' Sep 5 ','Labor Day','FEDERAL',CURDATE(),'DBA');

INSERT INTO `holidays` (`day`,`reason`,`type`,`created_at`, `created_by`)
  VALUES (' Nov 11 ','Veterans Day','FEDERAL',CURDATE(),'DBA');
  -- Insert sample examination results
INSERT INTO contact3 (id,name, exam_result)
VALUES (1213,'John Doe', 'A (OUTSTANDING)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1214,'Alex', 'B (GOOD)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1215,'Dillhoff', 'B (GOOD)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1216,'Park donhoof', 'A (OUTSTANDING)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1217,'Ahmed Kamangar', 'A (OUTSTANDING)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1218,'Astitos', 'F (FAIL)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1219,'Gayathri', 'A (OUTSTANDING)');
INSERT INTO contact3 (id,name, exam_result)
VALUES (1220,'Mahesh Babu', 'C (FAIR)
');


