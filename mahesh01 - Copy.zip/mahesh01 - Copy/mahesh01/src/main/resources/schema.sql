CREATE TABLE IF NOT EXISTS `contact_msg` (
  `contact_id` int AUTO_INCREMENT  PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `mobile_num` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` TIMESTAMP NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `updated_at` TIMESTAMP DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
);
CREATE TABLE PAYMENT_MSG (
`id` int AUTO_INCREMENT  PRIMARY KEY,
    STUDENT_ID INT,
    NAME VARCHAR(255),
    CARDHOLDERNAME VARCHAR(255),
    CARDHOLDERADDRESS VARCHAR(255),
    CITY VARCHAR(255),
    STATE VARCHAR(255),
    ZIPCODE VARCHAR(10),
    CARDNUMBER VARCHAR(90),
    EXPIRATIONMONTH INT,
    EXPIRATIONYEAR INT,
    CVV VARCHAR(4),
    FEEAMOUNT DECIMAL(10, 2),
    MOBILE_NUM VARCHAR(15),
    STATUS VARCHAR(50),
    CREATED_AT TIMESTAMP,
    CREATED_BY VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS `application` (
  `application_id` int AUTO_INCREMENT  PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `mobile_num` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `resume` varchar(10) Not NULL,
  `status` varchar(10) NOT NULL,
    `created_at` TIMESTAMP NOT NULL,
    `created_by` varchar(50) NOT NULL,
    `updated_at` TIMESTAMP DEFAULT NULL,
    `updated_by` varchar(50) DEFAULT NULL
);
CREATE TABLE IF NOT EXISTS `holidays` (
  `day` varchar(20) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL,
  `created_at` TIMESTAMP NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `updated_at` TIMESTAMP DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
);
CREATE TABLE IF NOT EXISTS `housing_msg` (
  `housing_id` int AUTO_INCREMENT  PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `mobile_num` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `house_plan` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` TIMESTAMP NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `updated_at` TIMESTAMP DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
);
CREATE TABLE IF NOT EXISTS `transport_msg` (
  `student_id` INT   PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `mobile_num` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(30) NOT NULL,
  `to_address` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL,
  `created_at` TIMESTAMP NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `updated_at` TIMESTAMP DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL
);
-- Create the examination_result table

CREATE TABLE IF NOT EXISTS `contact3` (
    id INT PRIMARY KEY,
    name VARCHAR(255),
    exam_result VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS `feepayment` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `studentid` INT NOT NULL,
    `studentname` VARCHAR(255) NOT NULL,
    `cardholdername` VARCHAR(255) NOT NULL,
    `cardholderaddress` VARCHAR(255) NOT NULL,
    `city` VARCHAR(255) NOT NULL,
    `state` VARCHAR(255) NOT NULL,
    `zipcode` VARCHAR(10) NOT NULL,
    `cardnumber` VARCHAR(255) NOT NULL,
    `expirationmonth` VARCHAR(2) NOT NULL,
    `expirationyear` VARCHAR(4) NOT NULL,
    `cvv` VARCHAR(3) NOT NULL,
    `feeamount` DECIMAL(10, 2) NOT NULL,
    `mobilenumber` VARCHAR(10) NOT NULL,
    `status` varchar(10) NOT NULL,
    `created_at` TIMESTAMP NOT NULL,
     `created_by` varchar(50) NOT NULL,
     `updated_at` TIMESTAMP DEFAULT NULL,
     `updated_by` varchar(50) DEFAULT NULL
);