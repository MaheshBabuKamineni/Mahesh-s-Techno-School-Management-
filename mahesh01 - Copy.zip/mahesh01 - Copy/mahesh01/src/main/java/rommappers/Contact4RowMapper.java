package rommappers;

import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.model.Contact4;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Contact4RowMapper implements RowMapper<Contact4> {
    @Override
    public Contact4 mapRow(ResultSet rs, int rowNum) throws SQLException {
        Contact4 contact4 = new Contact4();
        contact4.setStudentId(rs.getInt("Student_ID"));
        contact4.setName(rs.getString("NAME"));
        contact4.setMobileNum(rs.getString("MOBILE_NUM"));
        contact4.setEmail(rs.getString("EMAIL"));
        contact4.setToAddress(rs.getString("TO_ADDRESS"));

        contact4.setStatus(rs.getString("STATUS"));
        contact4.setCreatedAt(rs.getTimestamp("CREATED_AT").toLocalDateTime());
        contact4.setCreatedBy(rs.getString("CREATED_BY"));

        if(null!=rs.getTimestamp("UPDATED_AT")){
            contact4.setUpdatedAt(rs.getTimestamp("UPDATED_AT").toLocalDateTime());
        }
        contact4.setUpdatedBy(rs.getString("UPDATED_BY"));
        return contact4;
    }

}
