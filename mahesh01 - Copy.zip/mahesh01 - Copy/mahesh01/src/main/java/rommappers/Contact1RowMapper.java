package rommappers;

import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Contact1;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;


public class Contact1RowMapper implements RowMapper<Contact1> {
    @Override
    public Contact1 mapRow(ResultSet rs, int rowNum) throws SQLException {
        Contact1 contact1 = new Contact1();
        contact1.setHousingId(rs.getInt("HOUSING_ID"));
        contact1.setName(rs.getString("NAME"));
        contact1.setMobileNum(rs.getString("MOBILE_NUM"));
        contact1.setEmail(rs.getString("EMAIL"));
        contact1.setHousePlan(rs.getString("HOUSE_PLAN"));

        contact1.setStatus(rs.getString("STATUS"));
        contact1.setCreatedAt(rs.getTimestamp("CREATED_AT").toLocalDateTime());
        contact1.setCreatedBy(rs.getString("CREATED_BY"));

        if(null!=rs.getTimestamp("UPDATED_AT")){
            contact1.setUpdatedAt(rs.getTimestamp("UPDATED_AT").toLocalDateTime());
        }
        contact1.setUpdatedBy(rs.getString("UPDATED_BY"));
        return contact1;
    }


}
