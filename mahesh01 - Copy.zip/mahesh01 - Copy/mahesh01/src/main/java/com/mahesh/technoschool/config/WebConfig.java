package com.mahesh.technoschool.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
@Configuration
public class WebConfig implements WebMvcConfigurer {




    public void addViewControllers(ViewControllerRegistry registry)
    {
        registry.addViewController("/courses").setViewName("courses");
        registry.addViewController("/about").setViewName("about");
        registry.addViewController("/careers").setViewName("careers");
        registry.addViewController("/club").setViewName("club");
        registry.addViewController("/housing").setViewName("housing");
        registry.addViewController("/search").setViewName("search");
        registry.addViewController("/contact3").setViewName("contact3");
        registry.addViewController("/result").setViewName("result");
        registry.addViewController("/transport").setViewName("Transportation");
        registry.addViewController("/contact4").setViewName("contact4");

        registry.addViewController("/pay").setViewName("feepayment");








    }
}
