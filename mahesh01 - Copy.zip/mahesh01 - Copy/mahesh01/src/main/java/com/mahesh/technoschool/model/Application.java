package com.mahesh.technoschool.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;
import javax.persistence.Lob;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileInputStream;
import java.util.List;

@Data

public class Application  extends BaseEntity{
    private int applicationId;

    @NotBlank(message="Name must not be blank")
    @Size(min=3,message="name must be at least 3 characters long")
    private String name;
    @NotBlank(message="Email must not be blank")
    @Pattern(regexp = "(^|[0-9]{10})",message="Mobile number must be 10 digits")
    private String mobileNum;
    @NotBlank(message="Email must not be blank")
    @Email(message="Please provide a valid email address")
    private String email;
    @NotBlank(message="Resume must not be blank")
    @Lob

    private byte[] resume;

    private String status;

}
