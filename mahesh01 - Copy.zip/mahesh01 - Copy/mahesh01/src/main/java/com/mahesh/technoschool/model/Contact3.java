package com.mahesh.technoschool.model;

import lombok.Data;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
public class Contact3 {
    private Long id;
    private String name;


    private String examResult;


}
