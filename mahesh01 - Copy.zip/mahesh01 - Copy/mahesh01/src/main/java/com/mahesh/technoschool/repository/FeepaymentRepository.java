package com.mahesh.technoschool.repository;

import com.mahesh.technoschool.model.Feepayment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

@Repository
public class FeepaymentRepository {

    private final JdbcTemplate jdbcTemplate;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public FeepaymentRepository(JdbcTemplate jdbcTemplate, BCryptPasswordEncoder passwordEncoder) {
        this.jdbcTemplate = jdbcTemplate;
        this.passwordEncoder = passwordEncoder;
    }

    public int saveContactMsg1(Feepayment feepayment) {
        String hashedCreditCard = passwordEncoder.encode(feepayment.getCardNumber());
        String sql = "INSERT INTO PAYMENT_MSG (STUDENT_ID,NAME,CARDHOLDERNAME,CARDHOLDERADDRESS,CITY," +
                "STATE,ZIPCODE,CARDNUMBER,EXPIRATIONMONTH," +
                "EXPIRATIONYEAR,CVV,FEEAMOUNT,MOBILE_NUM,STATUS," +
                "CREATED_AT,CREATED_BY) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        return jdbcTemplate.update(sql, feepayment.getStudentId(), feepayment.getStudentName(),
                feepayment.getCardholderName(), feepayment.getCardholderAddress(), feepayment.getCity(),
                feepayment.getState(), feepayment.getZipcode(), hashedCreditCard, feepayment.getExpirationMonth(),
                feepayment.getExpirationYear(), feepayment.getCvv(), feepayment.getFeeAmount(), feepayment.getMobileNumber(),
                feepayment.getStatus(), feepayment.getCreatedAt(), feepayment.getCreatedBy());
    }
}
