package com.mahesh.technoschool.service;

import com.mahesh.technoschool.constants.TechnoSchoolConstants;
import com.mahesh.technoschool.model.Application;
import com.mahesh.technoschool.repository.ApplicationRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@Slf4j

public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    public ApplicationService(ApplicationRepository applicationRepository) {
        this.applicationRepository = applicationRepository;
    }

    public boolean saveMessageDetails(Application application) {
        boolean isSaved = false;
        application.setStatus(TechnoSchoolConstants.OPEN);
        application.setCreatedBy(TechnoSchoolConstants.ANONYMOUS);
        application.setCreatedAt(LocalDateTime.now());
        int result = applicationRepository.saveContactMsg(application);
        if (result > 0) {
            isSaved = true;
        }
        return isSaved;
    }
}
