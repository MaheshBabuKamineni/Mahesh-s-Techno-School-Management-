package com.mahesh.technoschool.controller;

import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.model.Contact4;
import com.mahesh.technoschool.service.Contact1Service;
import com.mahesh.technoschool.service.Contact4Service;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@Slf4j
public class Contact4Controller {
    private final Contact4Service contact4Service;

    @Autowired
    public Contact4Controller(Contact4Service contact4Service) {
        this.contact4Service = contact4Service;
    }

    @RequestMapping("/contact4")
    public String displayContactPage(Model model) {
        model.addAttribute("contact4", new Contact4());
        return "contact4.html";
    }
    @RequestMapping(value = "/saveMsg4",method = RequestMethod.POST)
    public String saveMessage(@Valid @ModelAttribute("contact4") Contact4 contact4, Errors errors) {
        if(errors.hasErrors()){
            log.error("Contact form validation failed due to : " + errors.toString());
            return "contact4.html";
        }
        contact4Service.saveMessageDetails(contact4);
        return "redirect:/contact4";

    }

    @RequestMapping("/displayMessages4")
    public ModelAndView displayMessages(Model model) {
        List<Contact4> contactMsgs = contact4Service.findMsgsWithOpenStatus();
        ModelAndView modelAndView = new ModelAndView("messages4.html");
        modelAndView.addObject("contactMsgs",contactMsgs);
        return modelAndView;
    }
    @RequestMapping(value = "/closeMsg4",method = RequestMethod.GET)
    public String closeMsg(@RequestParam int id, Authentication authentication) {
        contact4Service.updateMsgStatus(id,authentication.getName());
        return "redirect:/displayMessages4";
    }

}
