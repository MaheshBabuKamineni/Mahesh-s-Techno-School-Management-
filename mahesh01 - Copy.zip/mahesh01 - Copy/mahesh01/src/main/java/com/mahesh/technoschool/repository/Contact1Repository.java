package com.mahesh.technoschool.repository;

import com.mahesh.technoschool.constants.TechnoSchoolConstants;
import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Contact1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import rommappers.Contact1RowMapper;
import rommappers.ContactRowMapper;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@Repository

public class Contact1Repository {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public Contact1Repository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int saveContactMsg(Contact1 contact1){
        String sql = "INSERT INTO HOUSING_MSG (NAME,MOBILE_NUM,EMAIL,HOUSE_PLAN,STATUS," +
                "CREATED_AT,CREATED_BY) VALUES (?,?,?,?,?,?,?)";
        return jdbcTemplate.update(sql,contact1.getName(),contact1.getMobileNum(),
                contact1.getEmail(),contact1.getHousePlan(),
                contact1.getStatus(),contact1.getCreatedAt(),contact1.getCreatedBy());
    }
    public List<Contact1> findMsgsWithStatus(String status) {
        String sql = "SELECT * FROM HOUSING_MSG WHERE STATUS = ?";
        return jdbcTemplate.query(sql,new PreparedStatementSetter() {
            public void setValues(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1, status);
            }
        },new Contact1RowMapper());
    }
    public int updateMsgStatus(int housingId, String status,String updatedBy) {
        String sql = "UPDATE HOUSING_MSG SET STATUS = ?, UPDATED_BY = ?,UPDATED_AT =? WHERE housing_ID = ?";
        return jdbcTemplate.update(sql,new PreparedStatementSetter() {
            public void setValues(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1, status);
                preparedStatement.setString(2, updatedBy);
                preparedStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                preparedStatement.setInt(4, housingId);
            }
        });
    }


}
