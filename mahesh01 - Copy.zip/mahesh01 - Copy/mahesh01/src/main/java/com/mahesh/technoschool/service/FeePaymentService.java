package com.mahesh.technoschool.service;

import com.mahesh.technoschool.constants.TechnoSchoolConstants;
import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Feepayment;
import com.mahesh.technoschool.repository.ContactRepository;
import com.mahesh.technoschool.repository.FeepaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class FeePaymentService {
    @Autowired
    private FeepaymentRepository feepaymentRepository;
    public boolean saveMessageDetails(Feepayment feepayment){
        boolean isSaved = false;
        feepayment.setStatus(TechnoSchoolConstants.OPEN);
        feepayment.setCreatedBy(TechnoSchoolConstants.ANONYMOUS);
        feepayment.setCreatedAt(LocalDateTime.now());
        int result = feepaymentRepository.saveContactMsg1(feepayment);
        if(result>0) {
            isSaved = true;
        }
        return isSaved;
    }

}
