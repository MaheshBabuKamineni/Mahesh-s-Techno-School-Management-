package com.mahesh.technoschool.repository;

import com.mahesh.technoschool.model.Contact3;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.GetMapping;

@Repository
public class Contact3Repository {
    private final JdbcTemplate jdbcTemplate;

    public Contact3Repository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Contact3 findStudentById(Long id) {
        String sql = "SELECT * FROM contact3 WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, (rs, rowNum) -> {
            Contact3 contact3 = new Contact3();
            contact3.setId(rs.getLong("id"));
            contact3.setName(rs.getString("name"));
            contact3.setExamResult(rs.getString("exam_result"));
            return contact3;
        });
    }
}
