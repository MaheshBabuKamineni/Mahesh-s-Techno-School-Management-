package com.mahesh.technoschool.controller;

import com.mahesh.technoschool.model.Contact3;
import com.mahesh.technoschool.repository.Contact3Repository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Contact3Controller {
    private final Contact3Repository contact3Repository;

    public Contact3Controller(Contact3Repository contact3Repository) {
        this.contact3Repository = contact3Repository;
    }
    @RequestMapping(value = "/contact3",method = RequestMethod.GET)
    public String showForm() {
        // Code to display the form
        return "contact3.html";
    }


    @RequestMapping(value = "/contact3",method = RequestMethod.POST)
    public String searchResult(Long id, Model model) {
        Contact3 contact3 = contact3Repository.findStudentById(id);
        model.addAttribute("contact3", contact3);
        model.addAttribute("searched", true);
        return "contact3";
    }
}
