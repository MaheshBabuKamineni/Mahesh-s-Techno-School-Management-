package com.mahesh.technoschool.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data

public class Feepayment extends BaseEntity {
    private int Id;
    @NotNull(message = "Student ID cannot be null")
    private Long studentId;
    @NotBlank(message = "Student name is required")
    private String studentName;
    @NotBlank(message = "Cardholder name is required")
    private String cardholderName;
    @NotBlank(message = "Cardholder address is required")
    private String cardholderAddress;
    @NotBlank(message = "City is required")
    private String city;
    @NotBlank(message = "State is required")
    private String state;
    @NotBlank(message = "Zipcode is required")
    private String zipcode;
    @NotBlank(message = "Card number is required")
    private String cardNumber;
    @NotBlank(message = "Expiration month is required")
    private String expirationMonth;
    @NotBlank(message = "Expiration year is required")
    private String expirationYear;
    @NotBlank(message = "CVV is required")
    private String cvv;
    @NotNull(message = "Fee amount cannot be null")
    @DecimalMin(value = "0.01", message = "Fee amount must be greater than 0")
    private Double feeAmount;
    @NotBlank(message = "Mobile number is required")
    @Pattern(regexp = "\\d{10}", message = "Mobile number must be 10 digits")
    private String mobileNumber;
    private String status;
}
