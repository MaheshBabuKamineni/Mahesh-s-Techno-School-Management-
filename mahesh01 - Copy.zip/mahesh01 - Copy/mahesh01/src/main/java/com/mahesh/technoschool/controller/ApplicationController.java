package com.mahesh.technoschool.controller;

import com.mahesh.technoschool.model.Application;
import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.service.ApplicationService;
import com.mahesh.technoschool.service.ContactService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@Slf4j

public class ApplicationController {

    private ApplicationService applicationService;

    @Autowired
    public ApplicationController(ApplicationService applicationService) {
        this.applicationService = applicationService;
    }

    @RequestMapping("/jobapply")
    public String displayApplicationPage(Model model) {
        model.addAttribute("application", new Application());
        return "jobapply.html";
    }
}
