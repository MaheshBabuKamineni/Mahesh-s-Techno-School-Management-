package com.mahesh.technoschool.service;

import com.mahesh.technoschool.constants.TechnoSchoolConstants;
import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.repository.Contact1Repository;
import com.mahesh.technoschool.repository.ContactRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class Contact1Service {

    @Autowired
    private Contact1Repository contact1Repository;
    public boolean saveMessageDetails(Contact1 contact1){
        boolean isSaved = false;
        contact1.setStatus(TechnoSchoolConstants.OPEN);
        contact1.setCreatedBy(TechnoSchoolConstants.ANONYMOUS);
        contact1.setCreatedAt(LocalDateTime.now());
        int result = contact1Repository.saveContactMsg(contact1);
        if(result>0) {
            isSaved = true;
        }
        return isSaved;
    }
    public List<Contact1> findMsgsWithOpenStatus(){
        List<Contact1> contactMsgs = contact1Repository.findMsgsWithStatus(TechnoSchoolConstants.OPEN);
        return contactMsgs;
    }
    public boolean updateMsgStatus(int contactId, String updatedBy){
        boolean isUpdated = false;
        int result = contact1Repository.updateMsgStatus(contactId,TechnoSchoolConstants.CLOSE, updatedBy);
        if(result>0) {
            isUpdated = true;
        }
        return isUpdated;
    }
}
