package com.mahesh.technoschool.controller;

import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Feepayment;
import com.mahesh.technoschool.service.ContactService;
import com.mahesh.technoschool.service.FeePaymentService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
@Controller
@Slf4j
public class FeepaymentController {
    private final FeePaymentService feePaymentService;

    @Autowired
    public FeepaymentController(FeePaymentService feepaymentService) {
        this.feePaymentService = feepaymentService;
    }

    @RequestMapping("/pay")
    public String displayContactPage(Model model) {
        model.addAttribute("feepayment", new Feepayment());
        return "feepayment.html";
    }
    @RequestMapping(value = "/saveMsg5",method = RequestMethod.POST)
    public String saveMessage(@Valid @ModelAttribute("feepayment") Feepayment feepayment, Errors errors) {
        if(errors.hasErrors()){
            log.error("Contact form validation failed due to : " + errors.toString());
            return "feepayment.html";
        }
        feePaymentService.saveMessageDetails(feepayment);
        return "redirect:/pay";
    }
}
