package com.mahesh.technoschool.controller;

import com.mahesh.technoschool.model.Contact;
import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.service.Contact1Service;
import com.mahesh.technoschool.service.ContactService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@Slf4j
public class Contact1Controller {
    private final Contact1Service contact1Service;

    @Autowired
    public Contact1Controller(Contact1Service contact1Service) {
        this.contact1Service = contact1Service;
    }

    @RequestMapping("/contact1")
    public String displayContactPage(Model model) {
        model.addAttribute("contact1", new Contact1());
        return "contact1.html";
    }
    @RequestMapping(value = "/saveMsg1",method = RequestMethod.POST)
    public String saveMessage(@Valid @ModelAttribute("contact1") Contact1 contact1, Errors errors) {
        if(errors.hasErrors()){
            log.error("Contact form validation failed due to : " + errors.toString());
            return "contact1.html";
        }
        contact1Service.saveMessageDetails(contact1);
        return "redirect:/contact1";
    }
    @RequestMapping("/displayMessages1")
    public ModelAndView displayMessages(Model model) {
        List<Contact1> contactMsgs = contact1Service.findMsgsWithOpenStatus();
        ModelAndView modelAndView = new ModelAndView("messages1.html");
        modelAndView.addObject("contactMsgs",contactMsgs);
        return modelAndView;
    }
    @RequestMapping(value = "/closeMsg1",method = RequestMethod.GET)
    public String closeMsg(@RequestParam int id, Authentication authentication) {
        contact1Service.updateMsgStatus(id,authentication.getName());
        return "redirect:/displayMessages1";
    }
}
