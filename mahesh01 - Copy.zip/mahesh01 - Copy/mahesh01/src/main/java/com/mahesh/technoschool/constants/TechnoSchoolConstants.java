package com.mahesh.technoschool.constants;

public interface TechnoSchoolConstants {

    public static final String ANONYMOUS = "Anonymous";
    public static final String OPEN = "Open";
    public static final String CLOSE = "Close";
}
