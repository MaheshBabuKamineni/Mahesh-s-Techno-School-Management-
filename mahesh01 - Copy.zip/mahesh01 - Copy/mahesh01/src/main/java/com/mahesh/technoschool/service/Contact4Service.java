package com.mahesh.technoschool.service;

import com.mahesh.technoschool.constants.TechnoSchoolConstants;
import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.model.Contact4;
import com.mahesh.technoschool.repository.Contact1Repository;
import com.mahesh.technoschool.repository.Contact4Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class Contact4Service {
    @Autowired
    private Contact4Repository contact4Repository;
    public boolean saveMessageDetails(Contact4 contact4){
        boolean isSaved = false;
        contact4.setStatus(TechnoSchoolConstants.OPEN);
        contact4.setCreatedBy(TechnoSchoolConstants.ANONYMOUS);
        contact4.setCreatedAt(LocalDateTime.now());
        int result = contact4Repository.saveContactMsg(contact4);
        if(result>0) {
            isSaved = true;
        }
        return isSaved;
    }
    public List<Contact4> findMsgsWithOpenStatus(){
        List<Contact4> contactMsgs = contact4Repository.findMsgsWithStatus(TechnoSchoolConstants.OPEN);
        return contactMsgs;
    }
    public boolean updateMsgStatus(int contactId, String updatedBy){
        boolean isUpdated = false;
        int result = contact4Repository.updateMsgStatus(contactId,TechnoSchoolConstants.CLOSE, updatedBy);
        if(result>0) {
            isUpdated = true;
        }
        return isUpdated;
    }
}
