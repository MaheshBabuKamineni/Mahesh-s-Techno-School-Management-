package com.mahesh.technoschool.repository;

import com.mahesh.technoschool.model.Contact1;
import com.mahesh.technoschool.model.Contact4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import rommappers.Contact1RowMapper;
import rommappers.Contact4RowMapper;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
@Repository
public class Contact4Repository {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public Contact4Repository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public int saveContactMsg(Contact4 contact4){
        String sql = "INSERT INTO Transport_MSG (STUDENT_ID,NAME,MOBILE_NUM,EMAIL,ADDRESS,TO_ADDRESS,STATUS," +
                "CREATED_AT,CREATED_BY) VALUES (?,?,?,?,?,?,?,?,?)";
        return jdbcTemplate.update(sql,contact4.getStudentId(),contact4.getName(),contact4.getMobileNum(),
                contact4.getEmail(),contact4.getAddress(),contact4.getToAddress(),
                contact4.getStatus(),contact4.getCreatedAt(),contact4.getCreatedBy());
    }
    public List<Contact4> findMsgsWithStatus(String status) {
        String sql = "SELECT * FROM TRANSPORT_MSG WHERE STATUS = ?";
        return jdbcTemplate.query(sql,new PreparedStatementSetter() {
            public void setValues(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1, status);
            }
        },new Contact4RowMapper());
    }
    public int updateMsgStatus(int Student_id, String status,String updatedBy) {
        String sql = "UPDATE TRANSPORT_MSG SET STATUS = ?, UPDATED_BY = ?,UPDATED_AT =? WHERE STUDENT_ID = ?";
        return jdbcTemplate.update(sql,new PreparedStatementSetter() {
            public void setValues(PreparedStatement preparedStatement) throws SQLException {
                preparedStatement.setString(1, status);
                preparedStatement.setString(2, updatedBy);
                preparedStatement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                preparedStatement.setInt(4, Student_id);
            }
        });
    }
}
